package web.commands;

import business.exceptions.UserException;
import business.services.SVG;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ShowSVGCommand extends CommandUnprotectedPage {

    public ShowSVGCommand(String pageToShow) {
        super(pageToShow);
    }

    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws UserException {

        //TODO skal gøres dynamisk alle variabler skal gøres fuldt dynamiske via input fra bruger:

        int plankAmmount = 16;
        int pillarAmmount = 3;
        int pillarRows = 2;
        int shedPlankAmmount = 16;
        int fullLength = 810;
        int fullHeight = 660;
        int arrowLineFullHeight = fullHeight - 50;
        int arrowLineFullLength = fullLength - 50;


//        //Side drawing single :
//        SVG svg = new SVG(0, 0, "0 0 810 250", 100, 100);
//
//        //top tag
//        svg.addRect(50, 50, fullHeight - 210, fullLength - 60);
//
//        //Stolper
//        for (int x = 0; x < pillarAmmount; x++) {
//            svg.addRect(150 + 275 * x, 90, fullHeight - 90, 7.0);
//        }
//
//        // Skur side
//        for (int x = 0; x < shedPlankAmmount; x++) {
//            svg.addRect(fullLength - 210 + 12 * x, 90, fullHeight - 90, 4);
//        }
//
//        //omrids
//        for (int y = 0; y < 2; y++) {
//            svg.addLine(50, 0 + 250 * y, 800, 0 + 600 * y);
//            for (int x = 0; x < 2; x++) {
//                svg.addLine(50 + 750 * x, 0, 50 + 750 * x, 600);
//            }
//        }






            //svg for top view single
            SVG svg = new SVG(0, 0, "0 0 " +fullLength+" "+fullHeight+"", 100, 100);

            // Spær horisontalt
            for (int y = 0; y < 2; y++) {
                svg.addRect(50, 50 + 500 * y, 4.5, 750.0);
            }

            // Spær vertikalt
            for (int x = 0; x < plankAmmount; x++) {
                svg.addRect(50 + 50 * x, 0, 600.0, 4.5);
            }

            //Stolper
            for (int x = 0; x < pillarAmmount; x++) {
                int y;
                for (y = 0; y < pillarRows; y++) {
                    svg.addRect(150 + 275 * x, 50 + 500 * y, 7.0, 7.0);
                }
            }

            // Skur
            svg.addDashRect(600,50,500,150);

            // Stiplede linjer i kryds
            svg.addDashLine(100, 50, 600, 550);
            svg.addDashLine(100, 550, 600, 50);

            //omrids
            for (int y = 0; y < 2; y++) {
                svg.addLine(50, 0 + 600 * y, 800, 0 + 600 * y);
                for (int x = 0; x < 2; x++) {
                    svg.addLine(50 + 750 * x, 0, 50 + 750 * x, 600);
                }
            }

            // Lines til mål //TODO arrow integration - done
            svg.addDefs();
            svg.addArrowLine(5, 5, 5, arrowLineFullHeight);
            svg.addArrowLine(50, arrowLineFullHeight + 45, arrowLineFullLength +50, arrowLineFullHeight + 45);
            svg.addText(); // mangler parametre






        //Forsøg på ekstra test side - scrapped indtil videre.
//            {
//                //SVG svgSide = new SVG(0, 0, "0 0 810 600", 100, 100);
//
//                //omrids
//                for (int y = 0; y < 2; y++) {
//                    svg.addLine(50, 0 + 600 * y, 800, 0 + 600 * y);
//                    for (int x = 0; x < 2; x++) {
//                        svg.addLine(50 + 750 * x, 0, 50 + 750 * x, 600);
//                    }
//                }
//                request.setAttribute("svgsidedrawing", svg.toString());
//            }
//
//                request.setAttribute("svgtopdrawing", svg.toString());
//                return pageToShow;
//            }
        request.setAttribute("svgtopdrawing", svg.toString());
        return pageToShow;
    }
}
